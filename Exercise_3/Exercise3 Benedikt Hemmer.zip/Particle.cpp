#include "Particle.h"


Particle::Particle()
{
	Point zero;
	position = zero;
	velocity = zero;
	mass = 0.0;
}


